# PAT_100
PAT甲级的91题AC代码
The project is a preparation for the graduate entrance examination.
I did all the 91 problems from http://www.patest.cn/contests/pat-a-practise
I hope the project can give you some help.
If there is any thing wrong with the code, please let me know.
