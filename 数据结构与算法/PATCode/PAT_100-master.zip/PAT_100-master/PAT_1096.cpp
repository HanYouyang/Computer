//PAT_1096. Consecutive Factors (20)
//Miibotree
//2015.3.22
#include <stdio.h>

int main()
{
	
	return 0;
}